package cateringmanage;

import java.util.ArrayList;

public interface ICateringManage {
	
	public int selectWork();
	
	public void addFoods(String name,double price,String time);
	
	public void selectMenu();
	
	public void calculateBill(ArrayList<Food> menu);
	
	public void displayMenu(ArrayList<Food> menu);
	
	public boolean removeFood(String foodName,String time);
	
	public boolean updateFood(String foodName,double price,String time);

}
