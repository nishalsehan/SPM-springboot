package cateringmanage;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;



public class Activator implements BundleActivator {

	ServiceRegistration cateringServiceRegistration;
	
	@Override
	public void start(BundleContext context) throws Exception {
		System.out.println("Catering Service Started...");

		ICateringManage icateringManage = new CateringManageImpl();

		cateringServiceRegistration = context.registerService(ICateringManage.class.getName(), icateringManage, null);
	}
	
	@Override
	public void stop(BundleContext context) throws Exception {
		System.out.println("Catering Service Finished...");

		cateringServiceRegistration.unregister();
	}

}
