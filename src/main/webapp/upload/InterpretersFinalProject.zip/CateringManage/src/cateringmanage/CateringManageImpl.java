package cateringmanage;

import java.util.ArrayList;
import java.util.Scanner;



public class CateringManageImpl implements ICateringManage {

	private ArrayList<Food> lunchMenu;
	private ArrayList<Food> breakfastMenu;
	private ArrayList<Food> dinnerMenu;

	public CateringManageImpl() {
		breakfastMenu = new ArrayList<>();
		lunchMenu = new ArrayList<>();
		dinnerMenu = new ArrayList<>();

		Food food1 = new Food("String Hoppers", 50.0);
		breakfastMenu.add(food1);
		Food food2 = new Food("Pittu", 40.0);
		breakfastMenu.add(food2);

		Food food3 = new Food("Red rice", 120.0);
		lunchMenu.add(food3);
		Food food4 = new Food("Mixed rice", 180.0);
		lunchMenu.add(food4);

		Food food5 = new Food("Kottu", 200.0);
		dinnerMenu.add(food5);
		Food food6 = new Food("Hoppers", 15.0);
		dinnerMenu.add(food6);
	}

	public void addFoods(String name, double price, String time) {
		if (time.equals("breakfast")) {
			Food food = new Food(name, price);
			breakfastMenu.add(food);
			System.out.println("Successfully added");
		} else if (time.equals("lunch")) {
			Food food = new Food(name, price);
			lunchMenu.add(food);
			System.out.println("Successfully added");
		} else if (time.equals("dinner")) {
			Food food = new Food(name, price);
			dinnerMenu.add(food);
			System.out.println("Successfully added");
		} else {
			System.out.println("Invalid time");
			System.out.println("Adding Fail");
		}
	}

	@Override
	public void selectMenu() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("1.Breakfast");
		System.out.println("2.Lunch");
		System.out.println("3.Dinner");
		System.out.println("Select your menu number : ");
		String menu = scan.nextLine();

		if (menu.equals("1")) {
			this.displayMenu(breakfastMenu);
		} else if (menu.equals("2")) {
			this.displayMenu(lunchMenu);
		} else if (menu.equals("3")) {
			this.displayMenu(dinnerMenu);
		} else {
			System.out.println("Invalid time");
			this.selectMenu();
		}
	}

	@Override
	public void displayMenu(ArrayList<Food> menu) {
		int i = 1;
		int input;
		ArrayList<Food> selected = new ArrayList<>();
		System.out.println("\n\n\n--------Select your foods---------");
		for (Food m : menu) {
			System.out.println(i + ".  " + m.getName() + " : " + m.getPrice());
			++i;
		}
		Scanner scan = new Scanner(System.in);
		System.out.println("Select the food(to exit type -1)  :");
		input = scan.nextInt();
		if (input - 1 >= -2 || input - 1 < menu.size() || input != 0) {
			while (input != -1) {
				selected.add(menu.get(--input));

				System.out.println("Select the food(to exit type -1)  :");
				input = scan.nextInt();
			}
			this.calculateBill(selected);
		} else {
			System.out.println("Input invalid");
			this.displayMenu(menu);
		}
	}

	@Override
	public void calculateBill(ArrayList<Food> menu) {
		// TODO Auto-generated method stub
		double total = 0;
		System.out.println("\n\n\n----------Your Bill---------");

		for (Food m : menu) {
			total += m.getPrice();
			System.out.println(m.getName() + "       " + m.getPrice());
		}
		System.out.println("Total               " + total);

	}

	@Override
	public boolean removeFood(String foodName, String time) {
		// TODO Auto-generated method stub
		boolean status = false;
		if (time.equals("breakfast")) {
			for (Food m : breakfastMenu) {
				if (m.getName().equals(foodName)) {
					breakfastMenu.remove(m);
					status = true;
				}
			}
			if (status) {
				return true;
			} else {
				return false;
			}
		} else if (time.equals("lunch")) {
			for (Food m : lunchMenu) {
				if (m.getName().equals(foodName)) {
					dinnerMenu.remove(m);
					status = true;
				}
			}
			if (status) {
				return true;
			} else {
				return false;
			}
		} else if (time.equals("dinner")) {
			for (Food m : dinnerMenu) {
				if (m.getName().matches(foodName)) {
					dinnerMenu.remove(m);
					status = true;
					break;
				}
			}
			if (status) {
				return true;
			} else {
				return false;
			}
		} else {
			System.out.println("Invalid time");
			return false;
		}
	}

	@Override
	public boolean updateFood(String foodName, double price, String time) {
		// TODO Auto-generated method stub
		boolean status = false;
		if (time.equals("breakfast")) {
			for (Food m : breakfastMenu) {
				if (m.getName().equals(foodName)) {
					m.setPrice(price);
					status = true;
				}
			}
			if (status) {
				return true;
			} else {
				return false;
			}
		} else if (time.equals("lunch")) {
			for (Food m : lunchMenu) {
				if (m.getName().equals(foodName)) {
					m.setPrice(price);
					status = true;
				}
			}
			if (status) {
				return true;
			} else {
				return false;
			}
		} else if (time.equals("dinner")) {
			for (Food m : dinnerMenu) {
				if (m.getName().matches(foodName)) {
					m.setPrice(price);
					status = true;
					break;
				}
			}
			if (status) {
				return true;
			} else {
				return false;
			}
		} else {
			System.out.println("Invalid time");
			return false;
		}
	}

	@Override
	public int selectWork() {

		int number = 0;

		while (number != 99) {

			System.out.println("1. Add Foods To Hotel Menu");
			System.out.println("2. Show Hotel Food Menu");
			System.out.println("3. Update Foods");
			System.out.println("4. Order Foods");
			System.out.println("0.Back");
			System.out.println("99.Exit");
			System.out.print("Select your task : ");

			Scanner in = new Scanner(System.in);
			number = in.nextInt();

			if (number == 0) {
				return number;
			}

			switch (number) {
			case 1:
				System.out.println("------Now you can add foods--------");
				System.out.println("1.Breakfast");
				System.out.println("2.Lunch");
				System.out.println("3.Dinner");
				System.out.println("-------------------------------------");
				System.out.println("Select Menu time:");
				int addfoodtime_int = in.nextInt();

				String addfoodtime = "";

				if (addfoodtime_int == 1) {
					addfoodtime = "breakfast";
				} else if (addfoodtime_int == 2) {
					addfoodtime = "lunch";
				} else if (addfoodtime_int == 3) {
					addfoodtime = "dinner";
				} else {
					break;
				}

				System.out.println("Food Name:");
				String idnull = in.nextLine();
				String addfoodName = in.nextLine();
				System.out.println("Food Price:");
				double addfoodPrice = in.nextDouble();
				this.addFoods(addfoodName, addfoodPrice, addfoodtime);

				foodShowAll();

				break;

			case 2:

				foodShowAll();
				break;

			case 3:
				System.out.println("------Now you can update foods--------");

				System.out.println("1.Breakfast");
				System.out.println("2.Lunch");
				System.out.println("3.Dinner");
				System.out.println("-------------------------------------");
				System.out.println("Select Menu time:");
				int updatefoodtime_int = in.nextInt();

				String updatefoodtime = "";

				if (updatefoodtime_int == 1) {
					updatefoodtime = "breakfast";
				} else if (updatefoodtime_int == 2) {
					updatefoodtime = "lunch";
				} else if (updatefoodtime_int == 3) {
					updatefoodtime = "dinner";
				} else {
					break;
				}

				System.out.println("Food Name:");
				String idnull_2 = in.nextLine();
				String updatefoodName = in.nextLine();
				System.out.println("Food Price:");
				double updatefoodPrice = in.nextDouble();
				boolean result = this.updateFood(updatefoodName, updatefoodPrice, updatefoodtime);
				if (result) {
					System.out.println("Successfully Updated.");
				} else {
					System.out.println("Update failed.");
				}

				foodShowAll();

				break;
				
				
				
			case 4:
				
				
				this.selectMenu();
				
				break;
				
				
			/*
			 * case 5: System.out.println("------Now you can remove foods--------");
			 * 
			 * System.out.println("1.Breakfast"); System.out.println("2.Lunch");
			 * System.out.println("3.Dinner");
			 * System.out.println("-------------------------------------");
			 * System.out.println("Select Menu time:"); int removefoodtime_int =
			 * in.nextInt();
			 * 
			 * String removefoodtime = "";
			 * 
			 * if (removefoodtime_int == 1) { removefoodtime = "breakfast"; } else if
			 * (removefoodtime_int == 2) { removefoodtime = "lunch"; } else if
			 * (removefoodtime_int == 3) { removefoodtime = "dinner"; } else { break; }
			 * 
			 * System.out.println("Food Name:"); String idnull_3 = in.nextLine(); String
			 * removefoodName = in.next(); boolean result1 = this.removeFood(removefoodName,
			 * removefoodtime); if (result1) { System.out.println("Successfully Removed.");
			 * } else { System.out.println("Remove failed."); }
			 * 
			 * foodShowAll();
			 * 
			 * break;
			 */

			case 99:

				return number;
			default:
				System.out.println("!!!  Wrong Input .. Exiting... !!! ");
				break;
			}

			System.out.println("----------------------------");
			System.out.println("0.Back");
			System.out.println("99.Exit");

			number = in.nextInt();

		}
		return number;

	}

	public void foodShowAll() {

		int i = 0;
		int j = 0;
		int k = 0;

		System.out.println("-------------------- Breakfast Menu---------------------");

		for (Food food : breakfastMenu) {

			i++;

			System.out.println("----------  Food " + i + " -------");

			System.out.println("Name     : " + food.getName());
			System.out.println("Price   : " + food.getPrice());
		}

		System.out.println("-------------------- Lunch Menu---------------------");

		for (Food food : lunchMenu) {

			j++;

			System.out.println("----------  Food " + j + " -------");

			System.out.println("Name     : " + food.getName());
			System.out.println("Price   : " + food.getPrice());
		}

		System.out.println("-------------------- Dinner Menu---------------------");

		for (Food food : dinnerMenu) {

			k++;

			System.out.println("----------  Food " + k + " -------");

			System.out.println("Name     : " + food.getName());
			System.out.println("Price   : " + food.getPrice());
		}

	}

}
