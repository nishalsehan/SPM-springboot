package customermanage;

import java.util.ArrayList;

public class CustomerManageImpl implements ICustomerManage{

	ArrayList<Customer> customerList=new ArrayList<Customer>();	
	
	@Override
	public void addCustomer(String id, String name, String phone, String address) {
		Customer newCustomer = new Customer(id, name, phone , address);
		customerList.add(newCustomer);
		
	}
	
	@Override
	public ArrayList<Customer> newCustomerList() {		
		return customerList;
	}
	
}
