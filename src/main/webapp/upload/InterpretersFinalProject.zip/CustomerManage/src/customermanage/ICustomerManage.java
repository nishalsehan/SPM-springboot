package customermanage;

import java.util.ArrayList;

public interface ICustomerManage {
	
	public ArrayList<Customer> newCustomerList();
	public void addCustomer(String id, String name, String phone , String address);

}
