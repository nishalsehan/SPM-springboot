package employeemanage;

import java.util.ArrayList;

public class EmployeeManageImpl implements IEmployeeManage{
	
	ArrayList<Employee> employeeList;

	@Override
	public ArrayList<Employee> getEmployeeList() {
		
		employeeList=new ArrayList<Employee>();
		
		Employee employee1=new Employee("1", "Ganesh", "Manager","ganesh");
		Employee employee2=new Employee("2", "Nethu", "Receptionist","nethu");
		Employee employee3=new Employee("3", "Nihal", "Chef","nihal");
		Employee employee4=new Employee("4", "Akitha", "Room Manager","akitha");
		
		employeeList.add(employee1);
		employeeList.add(employee2);
		employeeList.add(employee3);
		employeeList.add(employee4);
		
		return employeeList;
	}

	@Override
	public void addEmployee(String id, String name, String post, String password) {
		
		Employee newEmployee=new Employee(id, name, post, password);
		employeeList.add(newEmployee);
		
		
	}

	@Override
	public ArrayList<Employee> newEmployeeList() {
		return this.employeeList;
	}

	/*
	 * @Override public void deleteEmployee(int id) {
	 * 
	 * 
	 * 
	 * int i=0;
	 * 
	 * for (Employee employee : employeeList) {
	 * 
	 * 
	 * 
	 * int realID=Integer.parseInt(employee.getId());
	 * 
	 * 
	 * if (id==realID) { employeeList.remove(i); }
	 * 
	 * i++; }
	 * 
	 * }
	 */
	

}
