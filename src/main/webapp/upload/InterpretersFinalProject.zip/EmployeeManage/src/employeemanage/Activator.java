package employeemanage;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class Activator implements BundleActivator {

	ServiceRegistration employeeServiceRegistration;
	
	@Override
	public void start(BundleContext context) throws Exception {
		System.out.println("Employee Service Started...");
		
		IEmployeeManage iEmployeeManage=new EmployeeManageImpl();
		
		
		employeeServiceRegistration = context.registerService(IEmployeeManage.class.getName(), iEmployeeManage, null);
		
		
		
	}
	
	@Override
	public void stop(BundleContext context) throws Exception {
		System.out.println("Employee Service Finished...");
		
		employeeServiceRegistration.unregister();
	}

}
