package employeemanage;

import java.util.ArrayList;

public interface IEmployeeManage {
	
	public ArrayList<Employee> getEmployeeList();
	public ArrayList<Employee> newEmployeeList();
	public void addEmployee(String id, String name, String post, String password);
	//public void deleteEmployee(int id);

}
