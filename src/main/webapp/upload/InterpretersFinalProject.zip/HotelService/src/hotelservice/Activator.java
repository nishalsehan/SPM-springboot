package hotelservice;

import cateringmanage.ICateringManage;
import customermanage.Customer;
import customermanage.ICustomerManage;
import employeemanage.Employee;
import employeemanage.IEmployeeManage;

import java.util.ArrayList;
import java.util.Scanner;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import roommanage.IRoomManage;
import roommanage.Room;

public class Activator implements BundleActivator {

	ServiceReference employeeServiceReference, roomServiceReference, customerServiceReference, cateringServiceReference;

	ArrayList<Employee> employeeList;
	ArrayList<Room> roomList;
	ArrayList<Customer> customerList;

	IEmployeeManage iEmployeeManage;
	IRoomManage iRoomManage;
	ICustomerManage icustomerManage;
	ICateringManage iCateringManage;

	Boolean isLogin;

	@Override
	public void start(BundleContext context) throws Exception {
		System.out.println("Welcome to hotel interpreters...");

		employeeServiceReference = context.getServiceReference(IEmployeeManage.class.getName());
		roomServiceReference = context.getServiceReference(IRoomManage.class.getName());
		customerServiceReference = context.getServiceReference(ICustomerManage.class.getName());
		cateringServiceReference = context.getServiceReference(ICateringManage.class.getName());

		iEmployeeManage = (IEmployeeManage) context.getService(employeeServiceReference);
		iRoomManage = (IRoomManage) context.getService(roomServiceReference);
		icustomerManage = (ICustomerManage) context.getService(customerServiceReference);
		iCateringManage = (ICateringManage) context.getService(cateringServiceReference);

		employeeList = iEmployeeManage.getEmployeeList();

		int number = 0;

		while (number != 99) {

			System.out.println("----- Login Page -----");
			System.out.println("Username	: ");

			Scanner in = new Scanner(System.in);
			String inUsername = in.nextLine();

			System.out.println("Password	: ");

			String inPassword = in.nextLine();

			isLogin = login(inUsername, inPassword);

			if (isLogin) {

				while (number != 99) {

					System.out.println("****  Main Menu   **** ");
					System.out.println("1.Register Customer");
					System.out.println("2.Room Booking");
					System.out.println("3.Meal Reserving");
					System.out.println("4.Employee Manage");
					System.out.println("99.Exit");

					number = in.nextInt();

					switch (number) {

					case 1:
						number = customerManageMenu();
						break;

					case 2:

						number = roomManageMenu();

						break;

					case 3:

						number = cateringManageMenu();

						break;

					case 4:

						number = employeeManageMenu();

						break;

					case 99:

						break;

					default:
						System.out.println("!!!  Wrong Input .. Exiting... !!! ");
						break;
					}

				}

			} else {
				continue;
			}

		} // end while

	}

	private int cateringManageMenu() {

		int number = iCateringManage.selectWork();

		return number;
	}

	private int customerManageMenu() {

		int number = 0;
		while (number != 99) {

			System.out.println("****  Customer Manage Menu   **** ");
			System.out.println("1.Add New Customer");
			System.out.println("2.Show All Customers");
			System.out.println("0.Back");
			System.out.println("99.Exit");

			Scanner in = new Scanner(System.in);
			number = in.nextInt();

			if (number == 0) {
				return number;
			}

			switch (number) {

			case 1:

				System.out.println("----------- Enter Customer Details -----------------");

				System.out.println("ID : ");
				String idnull = in.nextLine();
				String id = in.nextLine();
				System.out.println("Name : ");
				String name = in.nextLine();
				System.out.println("Phone : ");
				String phone = in.nextLine();
				System.out.println("Address : ");
				String address = in.nextLine();

				icustomerManage.addCustomer(id, name, phone, address);

				customerShowAll();

				break;

			case 2:

				customerShowAll();

				break;

			case 99:

				return number;

			default:
				System.out.println("!!!  Wrong Input .. Exiting... !!! ");
				break;
			}

			System.out.println("----------------------------");
			System.out.println("0.Back");
			System.out.println("99.Exit");

			number = in.nextInt();

		} // while end

		return number;

	}

	private int roomManageMenu() {

		int number = 0;
		while (number != 99) {

			System.out.println("****  Room Manage Menu   **** ");
			System.out.println("1.Assign New Room For Customer");
			System.out.println("2.Show All Assigned Rooms With Customers");
			// System.out.println("3.Delete Employee By ID");
			System.out.println("0.Back");
			System.out.println("99.Exit");

			Scanner in = new Scanner(System.in);
			number = in.nextInt();

			if (number == 0) {
				return number;
			}

			switch (number) {
			case 1:

				System.out.println("----------- Room Types -----------------");

				iRoomManage.viewType();

				System.out.println("----------- Enter Details -----------------");

				System.out.println("Enter the room type number: ");
				int typeRoom = in.nextInt();
				String idnull = in.nextLine();

				String type = null;

				if (typeRoom == 1) {
					type = "single";
				} else if (typeRoom == 2) {
					type = "double";
				} else if (typeRoom == 3) {
					type = "queen";
				} else if (typeRoom == 4) {
					type = "king";
				} else {
					break;
				}

				System.out.println("Enter a room number: ");
				String roomNo = in.nextLine();

				System.out.println("Enter customer ID: ");
				String customerId = in.nextLine();

				System.out.println("Enter the number of days: ");
				int days = in.nextInt();

				double price = iRoomManage.calculateRoomPrice(type, days);

				iRoomManage.assignNewRoom(type, roomNo, customerId, days, price);

				roomShowAll();

				break;

			case 2:

				roomShowAll();

				break;

			/*
			 * case 3:
			 * 
			 * System.out.println("Enter Employee ID : ");
			 * 
			 * 
			 * Scanner deleteID=new Scanner(System.in); int id_delete = deleteID.nextInt();
			 * iEmployeeManage.deleteEmployee(id_delete);
			 * 
			 * employeeShowAll();
			 * 
			 * break;
			 */

			case 99:

				return number;

			default:
				System.out.println("!!!  Wrong Input .. Exiting... !!! ");
				break;
			}

			System.out.println("----------------------------");
			System.out.println("0.Back");
			System.out.println("99.Exit");

			number = in.nextInt();

		} // while end

		return number;

	}

	public int employeeManageMenu() {

		int number = 0;
		while (number != 99) {

			System.out.println("****  Employee Manage Menu   **** ");
			System.out.println("1.Add New Employee");
			System.out.println("2.Show All Employees");
			// System.out.println("3.Delete Employee By ID");
			System.out.println("0.Back");
			System.out.println("99.Exit");

			Scanner in = new Scanner(System.in);
			number = in.nextInt();

			if (number == 0) {
				return number;
			}

			switch (number) {
			case 1:

				System.out.println("----------- Enter Employee Details -----------------");

				System.out.println("ID : ");
				String idnull = in.nextLine();
				String id = in.nextLine();
				System.out.println("Name : ");
				String name = in.nextLine();
				System.out.println("Post : ");
				String post = in.nextLine();
				System.out.println("Password : ");
				String password = in.nextLine();

				iEmployeeManage.addEmployee(id, name, post, password);

				employeeShowAll();

				break;

			case 2:

				employeeShowAll();

				break;

			/*
			 * case 3:
			 * 
			 * System.out.println("Enter Employee ID : ");
			 * 
			 * 
			 * Scanner deleteID=new Scanner(System.in); int id_delete = deleteID.nextInt();
			 * iEmployeeManage.deleteEmployee(id_delete);
			 * 
			 * employeeShowAll();
			 * 
			 * break;
			 */

			case 99:

				return number;

			default:
				System.out.println("!!!  Wrong Input .. Exiting... !!! ");
				break;
			}

			System.out.println("----------------------------");
			System.out.println("0.Back");
			System.out.println("99.Exit");

			number = in.nextInt();

		} // while end

		return number;

	}

	public void customerShowAll() {

		customerList = icustomerManage.newCustomerList();

		int i = 0;

		for (Customer customer : customerList) {
			i++;

			System.out.println("----------  Customer " + i + " -------");

			System.out.println("ID     : " + customer.getId());
			System.out.println("Name   : " + customer.getName());
			System.out.println("Phone  : " + customer.getPhone());
			System.out.println("Address: " + customer.getAddress());
		}
	}

	public void roomShowAll() {

		roomList = iRoomManage.getAssignedRoomList();

		int i = 0;

		for (Room room : roomList) {

			i++;

			System.out.println("----------  Assigned Room " + i + " -------");

			System.out.println("Type : " + room.getType());
			System.out.println("Room No : " + room.getRoomNo());
			System.out.println("Customer ID : " + room.getCustomerId());
			System.out.println("Days: " + room.getDays());
			System.out.println("Total Price: " + room.getPrice());
		}

	}

	public void employeeShowAll() {

		employeeList = iEmployeeManage.newEmployeeList();

		int i = 0;

		for (Employee employee : employeeList) {
			i++;

			System.out.println("----------  Employee " + i + " -------");

			System.out.println("ID : " + employee.getId());
			System.out.println("Name : " + employee.getName());
			System.out.println("Post : " + employee.getPost());
		}

	}

	public boolean login(String un, String pw) {

		for (Employee employee : employeeList) {

			String realUsername = employee.getName();
			String realPassword = employee.getPassword();

			if (un.equals(realUsername)) {

				if (pw.equals(realPassword)) {
					System.out.println("Login Success !!!");
					return true;
				} else {
					System.out.println("Pasword is Incorrect..");
					System.out.println("Login Failed !!!");
					return false;
				}

			} else {
				continue;
			}

		}

		System.out.println("Username is Incorrect..");
		System.out.println("Login Failed !!!");
		return false;

	}

	@Override
	public void stop(BundleContext context) throws Exception {
		System.out.println("Day off.. GoodBye...");
		context.ungetService(employeeServiceReference);
	}

}
