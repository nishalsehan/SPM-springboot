package roommanage;

import java.util.ArrayList;

public interface IRoomManage {
	
	public void assignNewRoom(String type, String roomNo,String custometId, int days,double price);
	public void viewType();
	public ArrayList<Room> getAssignedRoomList();
	
	public double calculateRoomPrice(String type,int days);

}
