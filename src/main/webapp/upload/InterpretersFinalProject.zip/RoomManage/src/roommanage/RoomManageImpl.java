package roommanage;

import java.util.ArrayList;

public class RoomManageImpl implements IRoomManage {

	ArrayList<Room> assignedRoomList=new ArrayList<Room>();

	@Override
	public void viewType() {

		System.out.println("1.Single");
		System.out.println("2.Double");
		System.out.println("3.Queen");
		System.out.println("4.King");

	}

	@Override
	public void assignNewRoom(String type, String roomNo, String customerId, int days, double price) {

		Room room = new Room(type, roomNo, customerId, days, price);
		assignedRoomList.add(room);

	}

	@Override
	public ArrayList<Room> getAssignedRoomList() {

		return this.assignedRoomList;
	}
	
	@Override
	public double calculateRoomPrice(String type, int days) {

		double amount=0;

		if (type == "single") {
			amount = 10000 * days;

		}

		else if (type == "double") {
			amount = 15000 * days;

		}

		else if (type == "queen") {
			amount = 25000 * days;

		}

		else if (type == "king") {
			amount = 30000 * days;

		}

		return amount;

	}


	
}
