package roommanage;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;



public class Activator implements BundleActivator {
	
	ServiceRegistration roomServiceRegistration;

	@Override
	public void start(BundleContext context) throws Exception {
		

		System.out.println("Room Service Started...");
		
		IRoomManage iRoomManage=new RoomManageImpl();
		
		
		roomServiceRegistration = context.registerService(IRoomManage.class.getName(), iRoomManage, null);
	}
	
	@Override
	public void stop(BundleContext context) throws Exception {
		
		System.out.println("Room Service Finished...");
		
		roomServiceRegistration.unregister();
	}

}
