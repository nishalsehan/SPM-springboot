package roommanage;

public class Room {
	
	
	private String type;
	private String roomNo;
	private String customerId;
	private int days;
	private double price;
	
	public Room(String type, String roomNo, String customerId, int days, double price) {
		super();
		this.type = type;
		this.roomNo = roomNo;
		this.customerId = customerId;
		this.days = days;
		this.price = price;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
	

	




	
}
