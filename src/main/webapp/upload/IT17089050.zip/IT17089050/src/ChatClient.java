
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;


public class ChatClient {

	BufferedReader in;
	PrintWriter out;
	JFrame frame = new JFrame("Chatter");
	JTextField textField = new JTextField(40);
	JTextArea messageArea = new JTextArea(8, 40);
	DefaultListModel model = new DefaultListModel();
	ArrayList<String> arrayList = new ArrayList<String>();
	ArrayList<String> senderList = new ArrayList<String>();
	JList list = new JList(model);
	JButton button = new JButton();
	JCheckBox checkBox = new JCheckBox("BroadCast");

	
	public ChatClient() {

		// Layout GUI
		textField.setEditable(false);
		messageArea.setEditable(false);

		frame.getContentPane().add(textField, "North");
		frame.getContentPane().add(new JScrollPane(messageArea), "Center");
		frame.getContentPane().add(new JScrollPane(list), "West");
		frame.getContentPane().add(button, "East");
		frame.getContentPane().add(checkBox, "South");
		frame.pack();

		
		
		button.setText("Click to send");
		
		
		
		list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		
		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
                
				if (!checkBox.isSelected()) {
					int selectedIndices[] = list.getSelectedIndices();
					for (int writer_index : selectedIndices) {
						senderList.add((String) list.getModel().getElementAt(writer_index));

					}
					out.println("ACTIVELIST " + senderList + "MESSAGE " + textField.getText());
					senderList.clear();
				}
				else if(checkBox.isSelected()){
					String msg = "BROADCAST " + textField.getText();
					out.println(msg);
					
					
				}

			}
		});
		textField.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				out.println(textField.getText());
				textField.setText("");
			}
		});

	}

	
	private String getServerAddress() {
		return JOptionPane.showInputDialog(frame, "Enter IP Address of the Server:", "Welcome to the Chatter",
				JOptionPane.QUESTION_MESSAGE);
	}

	
	private String getName() {
		return JOptionPane.showInputDialog(frame, "Choose a screen name:", "Screen name selection",
				JOptionPane.PLAIN_MESSAGE);
	}

	private void run() throws IOException {

		String serverAddress = getServerAddress();
		Socket socketX = new Socket(serverAddress, 9001);
		in = new BufferedReader(new InputStreamReader(socketX.getInputStream()));
		out = new PrintWriter(socketX.getOutputStream(), true);

		
		while (true) {
			String line = in.readLine();

		  
			if (line.startsWith("SUBMITNAME")) {
				String clientName = getName();
				out.println(clientName);
				frame.setTitle(clientName);
			} else if (line.startsWith("NAMEACCEPTED")) {
				textField.setEditable(true);

			} else if (line.startsWith("MESSAGE")) {
				messageArea.append(line.substring(8) + "\n");
			}
			else if (line.substring(line.indexOf("ACTIVELIST")) != null) {

				model.removeAllElements();
				System.out.println(line);
				line = line.substring(12, line.length() - 1);
				String[] arrayOfWriters = line.split(",");
				int i = 0;
				for (String writer : arrayOfWriters) {
					model.add(i, writer);
					i++;
				}
			}
		}
	}

	
	public static void main(String[] args) throws Exception {
		ChatClient client = new ChatClient();

		client.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		client.frame.setVisible(true);
		client.run();
	}
}