
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import javax.swing.BoxLayout;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JPanel;


public class ChatServer {

	
	private static final int PORT = 9001;
	private static HashSet<String> names = new HashSet<String>();
	private static HashMap<Socket, String> pointToPoint = new HashMap<Socket, String>();
	private static HashSet<PrintWriter> writers = new HashSet<PrintWriter>();
	private static ArrayList<String> activeList;
	public static void main(String[] args) throws Exception {
		System.out.println("The chat server is running.");
		ServerSocket listener = new ServerSocket(PORT);
		try {
			while (true) {
				Socket socket = listener.accept();
				Thread handlerThread = new Thread(new Handler(socket));
				handlerThread.start();
			}
		} finally {
			listener.close();
		}
	}

	
	private static class Handler implements Runnable {
		private String name;
		private Socket socket;
		private BufferedReader in;
		private PrintWriter out, writer;

		
		public Handler(Socket socket) {
			this.socket = socket;
		}
		public void run() {
			try {

				in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				out = new PrintWriter(socket.getOutputStream(), true);
				while (true) {
					out.println("SUBMITNAME");
					name = in.readLine();
					if (name == null) {
						return;
					}
					synchronized (names) {

						if (!names.contains(name)) {
							names.add(name);
							pointToPoint.put(socket, name);
							
							break;
						}
					}
				}

				out.println("NAMEACCEPTED");
				writers.add(out);
				for (Map.Entry<Socket, String> entry : pointToPoint.entrySet()) {
					Socket socket = entry.getKey();
					String mySocketName = entry.getValue();

					writer = new PrintWriter(socket.getOutputStream(), true);

					activeList = new ArrayList<String>();

					for (String writer_name : names) {

						if (!mySocketName.equals(writer_name)) {
							activeList.add(writer_name);
						}
					}
					writer.println("ACTIVELIST " + activeList);

				}
				

				while (true) {
					String input = in.readLine();
					if (input == null) {
						return;
					}
					System.out.println(input);

					
					if (input.contains(">>")) {

						String recieverName = input.substring(input.indexOf("MESSAGE ")+8, input.indexOf(">>"));
						for (Map.Entry<Socket, String> entry : pointToPoint.entrySet()) {

							Socket socket = entry.getKey();
							String Socketname = entry.getValue();

							writer = new PrintWriter(socket.getOutputStream(), true);
							if (Socketname.equals(recieverName) || Socketname.equals(name)) {

								writer.println("MESSAGE " + name + ": " + input.substring(input.indexOf(">>")+2));

							}

						}

					} else {
						if (input.startsWith("ACTIVELIST")) {

							System.out.println(input);
							String nameList = input.substring(12, (input.indexOf("MESSAGE")) - 1);
							String message = input.substring(input.indexOf("MESSAGE") + 7);
							
							String[] arrayOfWriters = nameList.split(",");

							for (String writerName : arrayOfWriters) {

								for (Map.Entry<Socket, String> entry : pointToPoint.entrySet()) {

									Socket socket = entry.getKey();
									String Socketname = entry.getValue();

									writer = new PrintWriter(socket.getOutputStream(), true);

									if (writerName.trim().equals(Socketname.trim()) || Socketname.trim().equals(name)) {

										writer.println("MESSAGE " + message);

									}

								}

							}
						}
						else if(input.startsWith("BROADCAST")) {
							
							String message = input.substring(input.indexOf("BROADCAST") + 9);
							
							for(PrintWriter writer : writers) {
								writer.println("MESSAGE " + message);
							}
							
							
							
						}

					}
					

				}

			} catch (IOException e) {
				System.out.println(e);
			} finally {
				
				if (name != null) {
					names.remove(name);

				}
				if (out != null) {
					writers.remove(out);

				}
				try {
					//Removing writers and update the list
					pointToPoint.remove(out);
					for (Map.Entry<Socket, String> entry : pointToPoint.entrySet()) {
						Socket socket = entry.getKey();
						String mySocketName = entry.getValue();

						writer = new PrintWriter(socket.getOutputStream(), true);

						activeList = new ArrayList<String>();

						for (String writer_name : names) {

							if (!mySocketName.equals(writer_name)) {
								activeList.add(writer_name);
							}
						}
						writer.println("ACTIVELIST " + activeList);

					}
					socket.close();
				} catch (IOException e) {
					System.out.println(name + " Good Bye");
				}
			}
		}
	}
}